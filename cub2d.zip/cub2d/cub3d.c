/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:46:55 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/28 18:43:55 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void    help_cast2(void)
{
	wall.foundVertWallHit = false;
	wall.vertWallHitX = 0;
	wall.vertWallHitY = 0;
	wall.xintercept = floor(nassim.x / TILE_SIZE) * TILE_SIZE;
	wall.xintercept += ray.isRayFacingRight ? TILE_SIZE : 0;
	wall.yintercept = nassim.y + (wall.xintercept - nassim.x) * tan(ray.rayAngle);
	wall.xstep = TILE_SIZE;
	wall.xstep *= ray.isRayFacingLeft ? -1 : 1;
	wall.ystep = TILE_SIZE * tan(ray.rayAngle);
	wall.ystep *= (ray.isRayFacingUp && wall.ystep > 0) ? -1 : 1;
	wall.ystep *= (ray.isRayFacingDown && wall.ystep < 0) ? -1 : 1;
	wall.nextVertTouchX = wall.xintercept;
	wall.nextVertTouchY = wall.yintercept;
}

void    cast_ray(int col, float angle)
{
	ray_direction(angle);

	help_cast();
	castwhile(wall.nextHorzTouchX , wall.nextHorzTouchY);
	// Increment wall.xstep and wall.ystep until we find a wall
	help_cast2();
	ray_direction(angle);

	// Increment wall.xstep and wall.ystep until we find a wall
	castwhile2(wall.nextVertTouchX , wall.nextVertTouchY);
	// Calculate both horizontal and vertical distances and choose the smallest value

	help_norm();
	help_nor2(col);
	color.colorr = rgb_to_int(color.color_x,color.color_y,color.color_z);

	// floor
	dda(game_data.resolution_y/2 + wall.wallStripHeight/2, col,game_data.resolution_y, col);

	// sma  
	color.colorr = rgb_to_int(color.color_xc,color.color_yc,color.color_zc);
	dda( 0, col ,game_data.resolution_y/2 - wall.wallStripHeight/2  ,col);

	ft_empty_trash(angle, col);
}

int main(int argc, char **argv)
{
	int		len;
	game_data.big_colon = 0;
	game_data.big_line = 0;  
	if (!(cub = (t_cub *)malloc(sizeof(t_cub))))
		exit_game(6);
	ft_bzero(cub, sizeof(t_cub));
	if (argc < 2 || argc > 3)
		exit_game(1);
	else if (!(len = ft_strlen(argv[1]) - 4))
		exit_game(2);
	else if (ft_strncmp(argv[1] + len, ".cub", 4))
		exit_game(3);
	if (argc == 3)
	{
		if (!ft_strncmp(argv[2], "--save", 6) && ft_strlen(argv[2]) == 6 )
			cub->save = 1;
		else
			exit_game(4);
	}
	init ();
	return(0);
}
