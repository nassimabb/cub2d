/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_readmap2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/15 18:32:56 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/28 17:26:15 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	free_tab(char **tab)
{
	int i;

	i = -1;
	if (tab)
	{
		while (tab[++i])
			free(tab[i]);
		free(tab);
	}
}


void    split_tab(char *line)
{
	int i;
	i = 0;
	char **tab = ft_split(line ,' ');
	if (ft_tablen(tab))
	{
		if (!ft_strncmp(tab[0],"R",1))
			ressolution(&game_data.resolution_x, &game_data.resolution_y, tab);
		else if (!ft_strncmp(tab[0],"NO",2))
			save_path(&game_data.no_path, &game_data.no_txt, tab, &text.no);
		else if (!ft_strncmp(tab[0],"SO",2))
			save_path(&game_data.so_path, &game_data.so_txt, tab, &text.so);
		else if (!ft_strncmp(tab[0],"WE",2))
			save_path(&game_data.we_path, &game_data.we_txt, tab, &text.we);
		else if (!ft_strncmp(tab[0],"EA",2))
			save_path(&game_data.ea_path, &game_data.ea_txt, tab, &text.ea);
		else if (!ft_strncmp(tab[0],"S",2))
			save_path(&game_data.s_path, &game_data.s_txt, tab, &text.s);
		else if (!ft_strncmp(tab[0],"F",1))
			save_color(tab);
		else if (!ft_strncmp(tab[0],"C",1))
			save_color(tab);
		else if (ft_isdigit(*line) || *line == ' ')
		{
			while(*line == ' ' || *line =='\t')
				line++;
			while (*(line + i) != '\0')
			{
				//printf("%c", line[i]);
				if (*(line + i) != '0' && *(line +i) != '1' && *(line + i) != '2' && *(line + i) != 'N' && *(line + i) != 'W' && *(line + i) != 'S' && *(line + i) != 'E')
					exit_game(11);
				i++;
			}
			map = ft_realloc(map, line);
			// check_map(cub);
		}
		check_identifier(tab[0]);
	}
	free_tab(tab);
	
}

void    ressolution(int* x , int* y, char **tab)
{
	text.r += 1;
	if (ft_strlen(tab[0]) != 1)
		exit_game(13);
	if (ft_tablen(tab) != 3)
		exit_game(23);
	int i;
	int len = ft_strlen(tab[1]);
	i = -1;
	while (++i < len)
		if (!ft_isdigit(tab[1][i]))
			exit_game(23);
	i = -1;
	len = ft_strlen(tab[2]);
	while (++i < len)
		if (!ft_isdigit(tab[2][i]))
			exit_game(23);
	*x = ft_atoi(tab[1]);
	*y = ft_atoi(tab[2]);
		if (*x > 2561 )
			*x = 2560;
		if (*y > 1440)
			*y = 1440;
	//free_tab(tab);
}

void save_path(char **path, char **text, char **tab, int *i)
{
	*i += 1;
	char *ext;
	if (ft_strlen(tab[0]) >= 3)
		exit_game(24);
	*path = ft_strdup(tab[0]);
    *text = ft_strdup(tab[1]);
	if (*text == NULL)
		exit_game(6);
	//tab[2] = ft_strjoin(" ",tab[2]);
	//tab[1] = ft_strjoin(tab[1],tab[2]);
	//printf("%s",tab[1]);
	ext = ft_strrchr(tab[1], '.');
	if (ft_strncmp(ext + 1,"xpm",3) != 0 || ft_strlen(ext + 1) > 3)
		exit_game(10);
//free_tab(tab);
}

void save_color(char **tab)
{
	if (ft_strlen(tab[0]) != 1)
		exit_game(24);
	if (!ft_strncmp(tab[0],"F",1))
	{
		text.f += 1;
		if (tab[1] != NULL)
    		ft_split2(tab[1]);
		else
			exit_game(6);
	}
	else if (!ft_strncmp(tab[0],"C",1))
	{
		text.c += 1;
		if (tab[1] != NULL)
			ft_splitc(tab[1]);
		else
			exit_game(6);
	}
}
