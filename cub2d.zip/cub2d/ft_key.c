/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_key.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/18 14:22:36 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/27 19:21:39 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void            my_mlx_pixel_put(int x, int y, int color)
{

	if (x < game_data.resolution_x && y < game_data.resolution_y && x >= 0 && y >= 0)
		dst[y * (int)game_data.resolution_x + x] = color;
}

int			key_press_hook(int keycode, void *ptr)
{
	ptr = NULL;
	if (keycode == EXIT_KEY)
		exit(1);
	if (keycode == KEY_UP)
		nassim.walkdirection = 1;
	if (keycode == KEY_DOWN)
		nassim.walkdirection = -1;
	if (keycode == KEY_RIGHT)
		nassim.turndirection = 1;
	if (keycode == KEY_LEFT)
		nassim.turndirection = -1;
    if (keycode == W)
		nassim.walkdirection = 1; // walkDirection
	if (keycode == S)
		nassim.walkdirection = -1;
	if (keycode == D)
		nassim.turndirection = 1; // turnDirection
	if (keycode == A)
		nassim.turndirection = -1;
	return (1);
}

int			key_release_hook(int keycode, void *ptr)
{
	ptr = NULL;
	if (keycode == KEY_UP)
		nassim.walkdirection = 0;
	if (keycode == KEY_DOWN)
		nassim.walkdirection = 0;
	if (keycode == KEY_RIGHT)
		nassim.turndirection = 0;
	if (keycode == KEY_LEFT)
		nassim.turndirection = 0;
    if (keycode == W)
		nassim.walkdirection = 0; // walkDirection
	if (keycode == S)
		nassim.walkdirection = 0;
	if (keycode == D)
		nassim.turndirection = 0; // turnDirection
	if (keycode == A)
		nassim.turndirection = 0;
	return (1);
}

unsigned int	rgb_to_int(unsigned int r, unsigned int g, unsigned int b)
{
	int c;

	c = r;
	c = (c << 8) | g;
	c = (c << 8) | b;
	return (c);
}
