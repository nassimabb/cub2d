/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   readmaps.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/31 18:49:14 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/28 16:08:50 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"
void free_array(char **tab)
{
    int i;

    i = -1;
    while (tab[++i])
        free(tab[i]);
    free(tab);
}

char **fill_map()
{
    char **tab;
    int i;
    int j;

    if(!(tab = malloc(sizeof(char*) * (game_data.big_colon + 1))))
        exit_game(6);
    i = 0;
    while (i < game_data.big_colon)
    {
        if(!(tab[i] = malloc(sizeof(char) * game_data.big_line + 1)))
            exit_game(6);
        j = 0;
        while (j < game_data.big_line)
        {
            if (j < ft_strlen(map[i]))
                tab[i][j] = map[i][j];
            else
                tab[i][j] = '1';
            j++;
        }
        tab[i][j] = '\0';
        free(map[i]);
        
        i++; 
    }
    tab[i] = NULL;
    free(map);
    return tab;
}

void       ft_split2(char* tab)
{
    char **tab2;
    int i = 0;
    int len = 0;
    char* num;
    num = tab;
    tab2 = ft_split(num ,',');
    len = ft_tablen(tab2);
    if (len == 3)
    {
        while (i <= 2)
            check_color(tab2[i++]);
    }
    else
        exit_game(28);
    color.color_x = (ft_atoi(tab2[0]) >= 0 && ft_atoi(tab2[0]) <= 255) ? ft_atoi(tab2[0]) : exit_game(27);
    color.color_y = (ft_atoi(tab2[1]) >= 0 && ft_atoi(tab2[1]) <= 255) ? ft_atoi(tab2[1]) : exit_game(27);
    color.color_z = (ft_atoi(tab2[2]) >= 0 && ft_atoi(tab2[2]) <= 255) ? ft_atoi(tab2[2]) : exit_game(27);
    free_tab(tab2);
}

void       ft_splitc(char* tab)
{
    char **tab2;
    int i = 0;
    int len = 0;
    char* num;
    num = tab;
    tab2 = ft_split(num ,',');
    len = ft_tablen(tab2);
    if (len == 3)
    {
        while (i <= 2 )
            check_color(tab2[i++]);
    }
    else
        exit_game(28);
    color.color_xc = (ft_atoi(tab2[0]) >= 0 && ft_atoi(tab2[0]) <= 255) ? ft_atoi(tab2[0]) : exit_game(27);
    color.color_yc = (ft_atoi(tab2[1]) >= 0 && ft_atoi(tab2[1]) <= 255) ? ft_atoi(tab2[1]) : exit_game(27);
    color.color_zc = (ft_atoi(tab2[2]) >= 0 && ft_atoi(tab2[2]) <= 255) ? ft_atoi(tab2[2]) : exit_game(27);
    free_tab(tab2);
}

char    **ft_realloc(char **tab, char *element)
{
    int     i;
    char    **ret;
    int     len;

    i = -1;
    len = 1;

    if (text.r != 1 || text.no != 1 || text.so != 1 || text.ea != 1 || text.we != 1 || text.s != 1 || text.f != 1 || text.c != 1)
            exit_game(12);
    if (tab)
        len = ft_tablen(tab) + 1;
    if(!(ret = (char **)malloc(sizeof(char *) * (len + 1))))
        exit_game(6);
    while (++i < len - 1)
        ret[i] = ft_strdup(tab[i]);
    free_tab(tab);
    ret[i] = ft_strdup(element);
    ret[i + 1] = NULL;
    game_data.big_colon += 1;
    if (game_data.big_line < ft_strlen(element))
        game_data.big_line = ft_strlen(element);
        
    return (ret);
}

void       ft_readmap(void)
{
    char *line;
    int fd;


    map = NULL;
    line = NULL;                                                                                         
    fd = open("map.cub",O_RDONLY);
    while (get_next_line(fd,&line) == 1)
    {
        split_tab(line);
        free(line);
    }
    free(line);
    close(fd);
    
}

void init_identifiers(void)
{
    text.no = 0;
    text.ea = 0;
    text.so = 0;
    text.we = 0;
    text.s = 0;
    text.f = 0;
    text.c = 0;
}
