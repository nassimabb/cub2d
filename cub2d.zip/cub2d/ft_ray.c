/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ray.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/18 14:25:25 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/28 18:35:29 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void    help_cast(void)
{
    
    wall.foundHorzWallHit = false;
    wall.horzWallHitX = 0;
    wall.horzWallHitY = 0;

    // Find the y-coordinate of the closest horizontal grid intersenction
    wall.yintercept = floor(nassim.y / TILE_SIZE) * TILE_SIZE;
    wall.yintercept += ray.isRayFacingDown ? TILE_SIZE : 0;

    // Find the x-coordinate of the closest horizontal grid intersection
    wall.xintercept = nassim.x + (wall.yintercept - nassim.y) / tan(ray.rayAngle);

    // Calculate the increment wall.xstep and wall.ystep
    wall.ystep = TILE_SIZE;
    wall.ystep *= ray.isRayFacingUp ? -1 : 1;

    wall.xstep = TILE_SIZE / tan(ray.rayAngle);
    wall.xstep *= (ray.isRayFacingLeft && wall.xstep > 0) ? -1 : 1;
    wall.xstep *= (ray.isRayFacingRight && wall.xstep < 0) ? -1 : 1;

    wall.nextHorzTouchX = wall.xintercept;
    wall.nextHorzTouchY = wall.yintercept;

}

void castwhile(float touchX, float touchY)
{
    while (touchX >= 0 && touchX < game_data.big_colon * TILE_SIZE && touchY >= 0 && touchY < game_data.big_line * TILE_SIZE)
    {
        if (hasWallAt(touchX, touchY + (ray.isRayFacingUp ? -1 : 0)))
        {
            wall.foundHorzWallHit = true;
            wall.horzWallHitX = touchX;
            wall.horzWallHitY = touchY;
            break;
        }
        else
        {
            touchX += wall.xstep;
            touchY += wall.ystep;
        }
    }
}
void castwhile2(float touchX, float touchY)
{
    while (touchX >= 0 && touchX < game_data.big_colon * TILE_SIZE && touchY >= 0 && touchY < game_data.big_line * TILE_SIZE)
    {
        if (hasWallAt(touchX  - (ray.isRayFacingLeft ? 1 : 0), touchY))
        {
            wall.foundVertWallHit = true;
            wall.vertWallHitX = touchX;
            wall.vertWallHitY = touchY;
            break;
        }
        else
        {
            touchX += wall.xstep;
            touchY += wall.ystep;
        }
    }
}
void    help_norm()
{
    wall.horzHitDistance = (wall.foundHorzWallHit)
        ? distanceBetweenPoints(nassim.x, nassim.y, wall.horzWallHitX, wall.horzWallHitY)
        : INT_MAX;
    wall.vertHitDistance = (wall.foundVertWallHit)
        ? distanceBetweenPoints(nassim.x, nassim.y, wall.vertWallHitX, wall.vertWallHitY)
        : INT_MAX;

    ray.wallHitX = (wall.horzHitDistance < wall.vertHitDistance) ? wall.horzWallHitX : wall.vertWallHitX;
    ray.wallHitY = (wall.horzHitDistance < wall.vertHitDistance) ? wall.horzWallHitY : wall.vertWallHitY;
    ray.distance = (wall.horzHitDistance < wall.vertHitDistance) ? wall.horzHitDistance : wall.vertHitDistance;
    ray.wasHitVertical = (wall.vertHitDistance < wall.horzHitDistance);
   
}

void    help_nor2(int col)
{
    ray.distance *= cos(nassim.dirangle - ray.rayAngle);
    g_ray_distance[col] = ray.distance; 
    wall.perpDistance = ray.distance;
    wall.distanceProjPlane = (game_data.resolution_y / 2) / tan(FOV_ANGLE / 2);
    wall.projectedWallHeight = (TILE_SIZE / wall.perpDistance) * wall.distanceProjPlane;

    wall.wallStripHeight = wall.projectedWallHeight;
    wall.wallTopPixel = (game_data.resolution_y / 2) - (wall.wallStripHeight / 2);
    wall.wallTopPixel = wall.wallTopPixel < 0 ? 0 : wall.wallTopPixel;

    wall.wallBottomPixel = (game_data.resolution_y / 2) + (wall.wallStripHeight / 2);
    wall.wallBottomPixel = wall.wallBottomPixel > game_data.resolution_y ? game_data.resolution_y : wall.wallBottomPixel;
   
}