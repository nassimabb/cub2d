/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/26 00:47:43 by mazoukni          #+#    #+#             */
/*   Updated: 2021/03/27 19:36:32 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

static void	columns_edges_map()
{
	int i;
	int j;

	i = 0;
	while (i < game_data.big_colon)
	{
		if (map[i][0] != '1' && map[i][0] != ' ')
			exit_game(32);
		i++;
	}
	i = 0;
	j = 0;
	while (i < game_data.big_colon)
	{
		while (map[i][j])
			j++;
		j--;
		if (map[i][j] != '1' && map[i][j] != ' ')
			exit_game(33);
		i++;
		j = 0;
	}
}

static void	edges_map()
{
	int i;
	int j;

	i = 1;
    
	while (i < game_data.big_colon - 1)
	{
		j = 1;
		while (map[i][j])
		{
			if (map[i][j] == ' ' && ((j != 0 && map[i]\
					[j - 1] == '0') || (j != game_data.big_line - 1 && \
					map[i][j + 1] == '0') || map[i - 1][j] \
					== '0' || map[i + 1][j] == '0'))
				exit_game(29);
			j++;
		}
		i++;
	}
}

static void	rows_edges_map()
{
	int i;

	i = 0;
	while (map[0][i])
	{
		if (map[0][i] != '1' && map[0][i] != ' ')
			exit_game(30);
		i++;
	}
	i = 0;
	while (i < game_data.big_line)
	{
		if (map[game_data.big_colon - 1][i] != '1' \
				&& map[game_data.big_colon - 1][i] != ' ' && \
				map[game_data.big_colon - 1][i] != '\0')
			exit_game(31);
		i++;
	}
}

void	position_map(int i, int j)
{
	if (ft_isalpha(map[i][j]) && map[i][j] != 'N' && \
			map[i][j] != 'S' && map[i][j] != 'E' && \
			map[i][j] != 'W')
		exit_game(11);
    if ((map[i][j] == 'N' || map[i][j] == 'S' \
		|| map[i][j] == 'E' || map[i][j] == 'W')\
		&& text.id == 0)
	{
		nassim.x = (i + 0.5) * TILE_SIZE;
		nassim.y = (j + 0.5) * TILE_SIZE;
		text.id = 1;
	}
	else if ((map[i][j] == 'N' || map[i][j] == 'S' \
			|| map[i][j] == 'E' || map[i][j] == 'W')\
			&& text.id == 1)
		exit_game(21);
}

void		check_map()
{
	if (text.id == 0)
		exit_game(22);
	edges_map();
    rows_edges_map();
    columns_edges_map();
}