/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_resolution.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 05:35:54 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/30 06:03:06 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	set_resolution(char **tab, int i, int len)
{
	g_text.r += 1;
	if (ft_strlen(tab[0]) != 1)
		exit_game(13);
	if (ft_tablen(tab) != 3)
		exit_game(23);
	len = ft_strlen(tab[1]);
	while (++i < len)
	{
		if (!ft_isdigit(tab[1][i]))
			exit_game(23);
	}
}

int	iterate_map(int i)
{
	int	j;

	if (!g_tab)
		exit_game(6);
	while (++i < g_game_data.big_colon)
	{
		g_tab[i] = malloc(sizeof(char) * g_game_data.big_line + 1);
		if (!(g_tab[i]))
			exit_game(6);
		j = -1;
		while (++j < g_game_data.big_line)
		{
			if (j < ft_strlen(g_map[i]))
			{
				if (g_map[i][j] == ' ')
					g_map[i][j] = '1';
				g_tab[i][j] = g_map[i][j];
			}
			else
				g_tab[i][j] = '1';
		}
		g_tab[i][j] = '\0';
		free(g_map[i]);
	}
	return (i);
}
