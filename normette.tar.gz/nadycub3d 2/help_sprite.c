/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   help_sprite.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 04:38:13 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 18:25:18 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	init_sprites_pos(void)
{
	int			i;
	int			j;
	int			k;

	i = 0;
	j = 0;
	k = 0;
	while (g_map[i] != '\0' && k < g_game_data.nb_of_sprites)
	{
		j = 0;
		while (g_map[i][j] != '\0' && k < g_game_data.nb_of_sprites)
		{
			if (g_map[i][j] == '2')
			{
				g_s_data[k].x = (i + 0.5) * TILE_SIZE;
				g_s_data[k].y = (j + 0.5) * TILE_SIZE;
				k++;
			}
			j++;
		}
		i++;
	}
}

void	ft_draw_sprites(void)
{
	int	i;

	i = 0;
	while (i < g_game_data.nb_of_sprites)
	{
		g_s_data[i].distance = distance(g_nassim.x, g_nassim.y, \
g_s_data[i].x, g_s_data[i].y);
		i++;
	}
	ft_sort_sprites();
	i = 0;
	while (i < g_game_data.nb_of_sprites)
		ft_sprite(i++);
}

void	init_sprites(void)
{
	int			i;
	int			j;
	int			k;

	i = 0;
	j = 0;
	k = 0;
	while (g_map[i] != '\0')
	{
		j = 0;
		while (g_map[i][j] != '\0')
		{
			if (g_map[i][j] == '2')
				g_game_data.nb_of_sprites += 1;
			j++;
		}
		i++;
	}
	if (g_game_data.nb_of_sprites >= 50)
		exit_game(35);
	init_sprites_pos();
}

void	norm_texture(char *line, int i)
{
	if (line[i] == 'N' && line[i + 1] == 'O' )
	{
		if (g_text.no > 1)
			exit_game(14);
		g_text.no += 1;
		g_game_data.no_path = save_texture(line, i);
	}
	if (line[i] == 'S' && line[i + 1] == 'O')
	{
		if (g_text.so > 1)
			exit_game(14);
		g_text.so += 1;
		g_game_data.so_path = save_texture(line, i);
	}
	if (line[i] == 'E' && line[i + 1] == 'A' )
	{
		if (g_text.ea > 1)
			exit_game(14);
		g_text.ea = 1;
		g_game_data.ea_path = save_texture(line, i);
	}
	normtext(line, i);
}

void	loop(char *line, int i)
{
	while (*(line + i) != '\0')
	{
		if (*(line + i) != '0' && *(line + i) != ' ' && \
*(line + i) != '1' && *(line + i) != '2' && *(line + i) != 'N' && \
*(line + i) != 'W' && *(line + i) != 'S' && \
*(line + i) != 'E')
			exit_game(11);
		i++;
	}
}
