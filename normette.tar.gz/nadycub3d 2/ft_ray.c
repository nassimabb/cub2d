/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ray.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/18 14:25:25 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 17:59:03 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	help_cast(void)
{
	g_wall.foundHorzWallHit = false;
	g_wall.horzWallHitX = 0;
	g_wall.horzWallHitY = 0;
	g_wall.yintercept = floor(g_nassim.y / TILE_SIZE) * TILE_SIZE;
	g_wall.yintercept += ternary(g_ray.isRayFacingDown, TILE_SIZE, 0);
	g_wall.xintercept = g_nassim.x + (g_wall.yintercept - g_nassim.y) / \
tan(g_ray.rayAngle);
	g_wall.ystep = TILE_SIZE;
	g_wall.ystep *= ternary(g_ray.isRayFacingUp, -1, 1);
	g_wall.xstep = TILE_SIZE / tan(g_ray.rayAngle);
	g_wall.xstep *= ternary((g_ray.isRayFacingLeft && g_wall.xstep > 0), -1, 1);
	g_wall.xstep *= ternary((g_ray.isRayFacingRight && \
g_wall.xstep < 0), -1, 1);
	g_wall.nextHorzTouchX = g_wall.xintercept;
	g_wall.nextHorzTouchY = g_wall.yintercept;
}

void	castwhile(float touchX, float touchY)
{
	while (touchX >= 0 && touchX < g_game_data.big_colon * TILE_SIZE && \
touchY >= 0 && touchY < g_game_data.big_line * TILE_SIZE)
	{
		if (hasWallAt(touchX, touchY + (ternary(g_ray.isRayFacingUp, -1, 0))))
		{
			g_wall.foundHorzWallHit = true;
			g_wall.horzWallHitX = touchX;
			g_wall.horzWallHitY = touchY;
			break ;
		}
		else
		{
			touchX += g_wall.xstep;
			touchY += g_wall.ystep;
		}
	}
}

void	castwhile2(float touchX, float touchY)
{
	while (touchX >= 0 && touchX < g_game_data.big_colon * TILE_SIZE && \
touchY >= 0 && touchY < g_game_data.big_line * TILE_SIZE)
	{
		if (hasWallAt(touchX - (ternary(g_ray.isRayFacingLeft, 1, 0)), touchY))
		{
			g_wall.foundVertWallHit = true;
			g_wall.vertWallHitX = touchX;
			g_wall.vertWallHitY = touchY;
			break ;
		}
		else
		{
			touchX += g_wall.xstep;
			touchY += g_wall.ystep;
		}
	}
}

void	help_norm(void)
{
	g_wall.horzHitDistance = ternary((g_wall.foundHorzWallHit) \
, distanceBetweenPoints(g_nassim.x, g_nassim.y, \
g_wall.horzWallHitX, g_wall.horzWallHitY) \
, INT_MAX);
	g_wall.vertHitDistance = ternary((g_wall.foundVertWallHit) \
, distanceBetweenPoints(g_nassim.x, g_nassim.y, \
g_wall.vertWallHitX, g_wall.vertWallHitY) \
, INT_MAX);
	g_ray.wallHitX = ternary((g_wall.horzHitDistance < g_wall.vertHitDistance), \
g_wall.horzWallHitX, g_wall.vertWallHitX);
	g_ray.wallHitY = ternary((g_wall.horzHitDistance < g_wall.vertHitDistance), \
g_wall.horzWallHitY, g_wall.vertWallHitY);
	g_ray.distance = ternary((g_wall.horzHitDistance < g_wall.vertHitDistance), \
g_wall.horzHitDistance, g_wall.vertHitDistance);
	g_ray.wasHitVertical = (g_wall.vertHitDistance < g_wall.horzHitDistance);
}

void	help_nor2(int col)
{
	g_ray.distance *= cos(g_nassim.dirangle - g_ray.rayAngle);
	g_ray_distance[col] = g_ray.distance;
	g_wall.perpDistance = g_ray.distance;
	g_wall.distanceProjPlane = (g_game_data.resolution_y / 2) / \
tan(FOV_ANGLE / 2);
	g_wall.projectedWallHeight = (TILE_SIZE / \
g_wall.perpDistance) * g_wall.distanceProjPlane;
	g_wall.wallStripHeight = g_wall.projectedWallHeight;
	g_wall.wallTopPixel = (g_game_data.resolution_y / \
2) - (g_wall.wallStripHeight / 2);
	g_wall.wallTopPixel = ternary(g_wall.wallTopPixel < 0, \
0, g_wall.wallTopPixel);
	g_wall.wallBottomPixel = (g_game_data.resolution_y / \
2) + (g_wall.wallStripHeight / 2);
	g_wall.wallBottomPixel = ternary(g_wall.wallBottomPixel > g_game_data.resolution_y, \
g_game_data.resolution_y, g_wall.wallBottomPixel);
}
