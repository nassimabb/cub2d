/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   texture.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/26 16:53:08 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 18:18:32 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	ft_draw_texture(t_image ptr, int col, float wallstripheight)
{
	g_txt.start = (g_game_data.resolution_y / 2) - (wallstripheight / 2);
	g_txt.end = (g_game_data.resolution_y / 2) + (wallstripheight / 2);
	g_txt.texture_y = 0;
	g_txt.offset_x = ternary((g_ray.wasHitVertical), (int)g_ray.wallHitY % \
TILE_SIZE, (int)g_ray.wallHitX % TILE_SIZE);
	while (g_txt.start < g_txt.end)
	{
		g_txt.dist_from_top = g_txt.start + (wallstripheight / \
2) - (g_game_data.resolution_y / 2);
		g_txt.offset_y = (int)(g_txt.dist_from_top * (float)TILE_SIZE / \
wallstripheight);
		g_txt.color = ptr.data[g_txt.offset_y * TILE_SIZE + g_txt.offset_x];
		my_mlx_pixel_put(col, g_txt.start, g_txt.color);
		g_txt.start++;
	}
}

void	ft_empty_trash(float rayangle, int col)
{
	float	distanceprojplane;
	float	raydist;
	float	an;
	float	wallstripheight;
	float	offset;

	an = rayangle - g_ray.rayAngle;
	raydist = g_ray.distance * cos(an);
	distanceprojplane = (g_game_data.resolution_y / 2) / tan(FOV_ANGLE / 2);
	wallstripheight = (TILE_SIZE / raydist) * distanceprojplane;
	offset = ternary((g_ray.wasHitVertical == 0), fmod(g_ray.wallHitX, TILE_SIZE), \
fmod(g_ray.wallHitY, TILE_SIZE));
	if (g_ray.isRayFacingDown && !g_ray.wasHitVertical)
		ft_draw_texture(g_west, col, wallstripheight);
	else if (g_ray.isRayFacingLeft && g_ray.wasHitVertical)
		ft_draw_texture(g_east, col, wallstripheight);
	else if (g_ray.isRayFacingRight && g_ray.wasHitVertical)
		ft_draw_texture(g_south, col, wallstripheight);
	else if (g_ray.isRayFacingUp && !g_ray.wasHitVertical)
		ft_draw_texture(g_north, col, wallstripheight);
}

void	get_text_data(void)
{
	g_north.ptr = mlx_xpm_file_to_image(g_mlx, g_game_data.no_path, \
&g_north.width, &g_north.height);
	if (!g_north.ptr)
		exit_game(24);
	g_west.ptr = mlx_xpm_file_to_image(g_mlx, g_game_data.we_path, \
&g_west.width, &g_west.height);
	if (!g_west.ptr)
		exit_game(24);
	g_south.ptr = mlx_xpm_file_to_image(g_mlx, g_game_data.so_path, \
&g_south.width, &g_south.height);
	if (!g_south.ptr)
		exit_game(24);
	g_east.ptr = mlx_xpm_file_to_image(g_mlx, g_game_data.ea_path, \
&g_east.width, &g_east.height);
	if (!g_east.ptr)
		exit_game(24);
	g_sprite.ptr = mlx_xpm_file_to_image(g_mlx, g_game_data.s_path, \
&g_sprite.width, &g_sprite.height);
	if (!g_sprite.ptr)
		exit_game(24);
}

void	init_textures(void)
{
	get_text_data();
	if (g_north.ptr && g_west.ptr && g_south.ptr && g_east.ptr && g_sprite.ptr)
	{
		g_north.data = (int *)mlx_get_data_addr(g_north.ptr,
				&g_north.bits_per_pixel,
				&g_north.size_line, &g_north.endian);
		g_west.data = (int *)mlx_get_data_addr(g_west.ptr,
				&g_west.bits_per_pixel,
				&g_west.size_line, &g_west.endian);
		g_south.data = (int *)mlx_get_data_addr(g_south.ptr,
				&g_south.bits_per_pixel,
				&g_south.size_line, &g_south.endian);
		g_east.data = (int *)mlx_get_data_addr(g_east.ptr,
				&g_east.bits_per_pixel,
				&g_east.size_line, &g_east.endian);
		g_sprite.data = (int *)mlx_get_data_addr(g_sprite.ptr,
				&g_sprite.bits_per_pixel,
				&g_sprite.size_line, &g_sprite.endian);
	}
	else
		exit_game(6);
}

unsigned int	shadow(unsigned int color, int col)
{
	t_color			shadow;
	float			fact;
	unsigned int	dark;

	fact = 200 / g_ray_distance[col];
	shadow.r = (((color >> 16) & 0xFF)) * fact;
	shadow.g = (((color >> 8) & 0xFF)) * fact;
	shadow.b = ((color) & (0xFF)) * fact;
	dark = rgb_to_int(shadow.r, shadow.g, shadow.b);
	if (dark > color)
		dark = color;
	return (dark);
}
