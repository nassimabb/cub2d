/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cast.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 12:01:57 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 17:14:38 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	cast(void)
{
	float	rayangle;
	float	angle;
	int		i;

	i = 0;
	rayangle = (FOV_ANGLE / (g_game_data.resolution_x));
	angle = (g_nassim.dirangle) - (FOV_ANGLE / 2);
	while (i < g_game_data.resolution_x)
	{
		angle = normalizeAngle(angle);
		cast_ray(i, angle);
		angle += rayangle;
		i++;
	}
}

int	ft_update(void)
{
	if (g_img.img != NULL)
		mlx_destroy_image(g_mlx, g_img.img);
	g_img.img = mlx_new_image(g_mlx, g_game_data.resolution_x, \
g_game_data.resolution_y);
	g_dst = (int *)mlx_get_data_addr(g_img.img, \
&g_img.bits_per_pixel, &g_img.line_length,
			&g_img.endian);
	move_player();
	cast();
	ft_draw_sprites();
	if (g_cub->save == 1)
	{
		ft_handle_bmp();
		exit(0);
	}
	mlx_put_image_to_window(g_mlx, g_mlx_win, g_img.img, 0, 0);
	return (0);
}

void	get_player_pos(void)
{
	int	i;
	int	j;

	i = 0;
	g_text.id = 0;
	while (g_map[i] != NULL)
	{
		j = 0;
		while (g_map[i][j] != '\0')
		{
			if (g_map[i][j] == 'N' || g_map[i][j] == 'S' || \
g_map[i][j] == 'W' || g_map[i][j] == 'E')
			{
				dirangle(i, j);
			}
			j++;
		}
		i++;
	}
	g_nassim.dirangle = normalizeAngle(g_nassim.dirangle);
}

void	init_struct(void)
{
	g_nassim.rotationangle = M_PI;
	g_nassim.turndirection = 0;
	g_nassim.rotationspeed = 5 * M_PI / 180;
	g_nassim.walkdirection = 0;
	g_nassim.movespeed = 5.0;
}

void	dirangle(int i, int j)
{
	if (g_map[i][j] == 'E')
		g_nassim.dirangle = M_PI / 2;
	if (g_map[i][j] == 'W')
		g_nassim.dirangle = 3 * M_PI / 2;
	if (g_map[i][j] == 'N')
		g_nassim.dirangle = M_PI;
	if (g_map[i][j] == 'S')
		g_nassim.dirangle = 0;
	position_map(i, j);
}
