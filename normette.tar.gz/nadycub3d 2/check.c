/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/17 15:46:56 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 19:36:10 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	check_identifier(char *line)
{
	int	i;

	i = 0;
	if (line[i] == 'R' && g_text.r > 1)
		exit_game(13);
	if (line[i] == 'N' && line[i + 1] == 'O' && g_text.no > 1)
		exit_game(14);
	if (line[i] == 'S' && line[i + 1] == 'O' && g_text.so > 1)
		exit_game(15);
	if (line[i] == 'E' && line[i + 1] == 'A' && g_text.ea > 1)
		exit_game(16);
	if (line[i] == 'W' && line[i + 1] == 'E' && g_text.we > 1)
		exit_game(17);
	if (line[i] == 'S' && line[i + 1] == ' ' && g_text.s > 1)
		exit_game(18);
	if (line[i] == 'F' && line[i + 1] == ' ' && g_text.f > 1)
		exit_game(19);
	if (line[i] == 'C' && line[i + 1] == ' ' && g_text.c > 1)
		exit_game(20);
}

void	check_error(void)
{
	int	i;
	int	j;

	i = 0;
	while (i < g_game_data.big_colon)
	{
		j = 0;
		while (j < g_game_data.big_line)
			j++;
		i++;
	}
}

void	check_color(char *line, int i)
{
	int	tmp;

	if (i == 1)
	{
		while (line[i])
		{
			if (ft_issymbol(line[i]))
				exit_game(26);
			i++;
		}
	}
	else
	{
		tmp = ft_atoi(&line[i]);
		if (tmp < 0 || tmp > 255)
			exit_game(27);
	}
}

int	save_color(char *line, int i)
{
	int	color;
	int	j;
	
	j = 0;
	i++;
	check_color(line, i);
	while (ft_isspace(line[i]))
		i++;
	if (line[i] == ',' && ft_isdigit(line[i + 1]))
		exit_game(28);
	check_color(line, i);
	color = ft_atoi(&line[i]) * pow(2, 16);
	while (ft_isdigit(line[i]))
		i++;
	while (line[i] == ',' || line[i] == ' ')
	{
		if(line[i] == ',')
			j++;
		i++;
	}
	if (j >= 2)
		exit_game(28);
	check_color(line, i);
	color += ft_atoi(&line[i]) * pow(2, 8);
	j = 0;
	while (ft_isdigit(line[i]))
		i++;
	while (line[i] == ',' || line[i] == ' ')
	{
		if(line[i] == ',')
			j++;
		i++;
	}
	if (j >= 2)
		exit_game(28);
	check_color(line, i);
	color += ft_atoi(&line[i]);
	while (ft_isdigit(line[i]))
		i++;
	if (line[i] == ',')
		exit_game(28);
	return (color);
}

void	init_identifiers(void)
{
	g_text.no = 0;
	g_text.ea = 0;
	g_text.so = 0;
	g_text.we = 0;
	g_text.s = 0;
	g_text.f = 0;
	g_text.c = 0;
}
