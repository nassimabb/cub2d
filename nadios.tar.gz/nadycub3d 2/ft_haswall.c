/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_haswall.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 11:50:15 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/30 04:09:28 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int	hasWallAt(float x, float y)
{
	int	x0;
	int	y0;

	x0 = floor(x / TILE_SIZE);
	y0 = floor(y / TILE_SIZE);
	if (x0 < 0 || x0 >= g_game_data.big_colon || y0 < 0 || \
	y0 >= g_game_data.big_line)
		return (0);
	else if (g_map[x0][y0] == '1' )
		return (1);
	return (0);
}

int	hasspriteAt(float x, float y)
{
	int	x0;
	int	y0;

	x0 = floor(x / TILE_SIZE);
	y0 = floor(y / TILE_SIZE);
	if (x0 < 0 || x0 >= g_game_data.big_colon || \
	y0 < 0 || y0 >= g_game_data.big_line)
		return (0);
	else if (g_map[x0][y0] == '2' )
		return (1);
	return (0);
}

void	move_player(void)
{
	float	x;
	float	y;

	g_nassim.dirangle += g_nassim.turndirection * g_nassim.rotationspeed;
	g_nassim.movestep = g_nassim.walkdirection * g_nassim.movespeed;
	x = g_nassim.x + cos(g_nassim.dirangle) * g_nassim.movestep * 4;
	y = g_nassim.y + sin(g_nassim.dirangle) * g_nassim.movestep * 4;
	g_nassim.newplayerx = g_nassim.x + cos(g_nassim.dirangle) \
							* g_nassim.movestep;
	g_nassim.newplayery = g_nassim.y + sin(g_nassim.dirangle) \
							* g_nassim.movestep;
	if (!hasWallAt(x, y) && !hasspriteAt(x, y))
	{
		g_nassim.x = g_nassim.newplayerx;
		g_nassim.y = g_nassim.newplayery;
	}
}
