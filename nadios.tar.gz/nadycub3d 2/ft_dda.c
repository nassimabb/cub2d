/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dda.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:29:46 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/30 04:26:52 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

float	normalizeAngle(float angle)
{
	float	angler;

	angler = fmod (angle, (2 * M_PI));
	if (angle < 0)
		angler = (2 * M_PI) + angle;
	return (angler);
}

float	distanceBetweenPoints(float x1, float y1, float x2, float y2)
{
	return (sqrtf ((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1)));
}

void	dda(float X0, float Y0, float X1, float Y1)
{
	g_dda.i = 0;
	g_dda.dx = X1 - X0;
	g_dda.dy = Y1 - Y0;
	g_dda.steps = ternary(abs (g_dda.dx) > abs (g_dda.dy), \
					abs (g_dda.dx), abs (g_dda.dy));
	g_dda.Xinc = g_dda.dx / (float) g_dda.steps;
	g_dda.Yinc = g_dda.dy / (float) g_dda.steps;
	g_dda.X = X0;
	g_dda.Y = Y0;
	while (g_dda.i <= g_dda.steps)
	{
		my_mlx_pixel_put(g_dda.Y, g_dda.X, g_color.colorr);
		g_dda.X += g_dda.Xinc;
		g_dda.Y += g_dda.Yinc;
		g_dda.i++;
	}
}

void	ray_direction(float angle)
{
	g_ray.rayAngle = normalizeAngle(angle);
	g_ray.wallHitX = 0;
	g_ray.wallHitY = 0;
	g_ray.distance = 0;
	g_ray.wasHitVertical = false;
	g_ray.isRayFacingDown = g_ray.rayAngle > 0 && g_ray.rayAngle < M_PI;
	g_ray.isRayFacingUp = !g_ray.isRayFacingDown;
	g_ray.isRayFacingRight = g_ray.rayAngle \
	< (0.5 * M_PI) || g_ray.rayAngle > (1.5 * M_PI);
	g_ray.isRayFacingLeft = !g_ray.isRayFacingRight;
}

char	*save_texture(char *line, int i)
{
	char	*texture;

	while (ft_isalpha(line[i]))
		i++;
	while (ft_isspace(line[i]))
		i++;
	texture = ft_strdup(&line[i]);
	return (texture);
}
