/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   readmaps.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/31 18:49:14 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 22:15:43 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	free_array(char **tab)
{
	int	i;

	i = -1;
	while (tab[++i])
		free(tab[i]);
	free(tab);
}

int	ft_isspace(int c)
{
	if (c == ' ' || c == '\t' || c == '\v' || \
c == '\f' || c == '\r' || c == '\n')
		return (1);
	return (0);
}

char	**fill_map(void)
{
	int		i;

	i = -1;
	g_tab = malloc(sizeof(char *) * (g_game_data.big_colon + 1));
	i = iterate_map(i);
	g_tab[i] = NULL;
	free(g_map);
	return (g_tab);
}

char	**ft_realloc(char **tab, char *element)
{
	int		i;
	char	**ret;
	int		len;

	i = -1;
	len = 1;
	if (g_text.r != 1 || g_text.no != 1 || g_text.so != 1 || \
g_text.ea != 1 || g_text.we != 1 || g_text.s != 1 || \
g_text.f != 1 || g_text.c != 1)
		exit_game(12);
	if (tab)
		len = ft_tablen(tab) + 1;
	ret = (char **)malloc(sizeof(char *) * (len + 1));
	if (!ret)
		exit_game(6);
	while (++i < len - 1)
		ret[i] = ft_strdup(tab[i]);
	free_tab(tab);
	ret[i] = ft_strdup(element);
	ret[i + 1] = NULL;
	g_game_data.big_colon += 1;
	if (g_game_data.big_line < ft_strlen(element))
		g_game_data.big_line = ft_strlen(element);
	return (ret);
}

void	ft_readmap(char *argv)
{
	char	*line;
	int		fd;

	g_map = NULL;
	line = NULL;
	fd = open(argv, O_RDONLY);
	if (fd < 1)
		exit_game(7);
	fd = open(argv, O_RDONLY);
	while (get_next_line(fd, &line) == 1)
	{
		split_tab(line);
		free(line);
	}
	free(line);
	close(fd);
}
