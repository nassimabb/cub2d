/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   cub3d.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/26 16:53:17 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 21:59:15 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef CUB3D_H
# define CUB3D_H

# include <unistd.h>
# include <mlx.h>
# include <fcntl.h>
# include "libft/libft.h"
# include "utils/utils.h"
# include <stdio.h>
# include "get_next_line/get_next_line.h"
# include <math.h>
# include <stdbool.h>
# include <limits.h>
# define EXIT_KEY		53
# define KEY_RIGHT		124
# define KEY_LEFT		123
# define KEY_DOWN		125
# define KEY_UP			126
# define W 13
# define S 1
# define D 2
# define A 0
# define TILE_SIZE      64
# define PI 3.14159265359
# define FOV_ANGLE 1.0471975512
# define MINI 0.3

typedef struct s_player
{
	int	x;
	int	y;
}				t_player;

typedef struct s_wall
{
	float	xintercept;
	float	yintercept;
	float	xstep;
	float	ystep;
	float	foundHorzWallHit;
	float	horzWallHitX;
	float	horzWallHitY;
	float	nextHorzTouchX;
	float	nextHorzTouchY;
	float	foundVertWallHit;
	float	vertWallHitX;
	float	vertWallHitY;
	float	nextVertTouchX;
	float	nextVertTouchY;
	float	horzHitDistance;
	float	vertHitDistance;
	float	perpDistance;
	float	distanceProjPlane;
	float	projectedWallHeight;
	int		wallStripHeight;
	int		wallTopPixel;
	int		wallBottomPixel;
}				t_wall;

typedef struct s_image
{
	int					width;
	int					height;
	int					bits_per_pixel;
	int					size_line;
	int					endian;
	void				*ptr;
	int					*data;
}						t_image;

typedef struct s_ident
{
	int				r;
	int				no;
	int				so;
	int				ea;
	int				we;
	int				s;
	int				f;
	int				c;
	int				player;
	int				id;
}					t_ident;

typedef struct s_ray
{
	float		rayAngle;
	float		wallHitX;
	float		wallHitY;
	float		distance;
	float		wasHitVertical;
	float		isRayFacingDown;
	float		isRayFacingUp;
	float		isRayFacingLeft;
	float		isRayFacingRight;
}				t_ray;

typedef struct s_plr
{
	float		rotationangle;
	float		turndirection;
	float		rotationspeed;
	float		walkdirection;
	float		movespeed;
	float		movestep;
	float		x;
	float		y;
	float		newplayerx;
	float		newplayery;
	float		dirangle;
}				t_plr;

typedef struct s_cub
{
	int			resolution_x;
	int			resolution_y;
	char		*no_path;
	char		*no_txt;
	char		*so_path;
	char		*so_txt;
	char		*we_path;
	char		*we_txt;
	char		*ea_path;
	char		*ea_txt;
	char		*s_path;
	char		*s_txt;
	int			big_line;
	int			big_colon;
	int			nb_of_sprites;
	int			save;
}				t_cub;

typedef struct s_color
{
	char		*flor_a;
	char		*flor_b;
	int			colorr;
	int			colorx;
	int			r;
	int			g;
	int			b;
	int			floor;
	int			ceiling;
}				t_color;

typedef struct s_data {
	void		*img;
	char		*addr;
	int			bits_per_pixel;
	int			line_length;
	int			endian;
}				t_data;

typedef struct s_sprit
{
	float				x;
	float				y;
	float				distance;
}						t_sprit;

typedef struct s_dda
{
	float		Xinc;
	float		Yinc;
	float		X;
	float		Y;
	int			steps;
	int			dx;
	int			dy;
	int			i;
}				t_dda;

typedef struct s_txt
{
	int		start;
	int		end;
	float	texture_y;
	int		color;
	int		offset_x;
	int		offset_y;
	int		dist_from_top;
}				t_txt;

t_image	g_north;
t_image	g_west;
t_image	g_south;
t_image	g_east;
t_image	g_sprite;
t_image	g_image;
t_plr	g_nassim;
t_txt	g_txt;
t_ray	g_ray;
t_cub	g_game_data;
t_cub	*g_cub;
t_wall	g_wall;
t_data	g_img;
t_color	g_color;
t_sprit	g_s_data[50];
t_ident	g_text;
t_dda	g_dda;
int		*g_dst;
char	**g_map;
char	**g_tab;
float	g_ray_distance[2561];
void	*g_mlx;
void	*g_mlx_win;

float					distanceBetweenPoints(float x1, float y1, \
						float x2, float y2);
float					distance(float x1, float y1, float x2, float y2);
int						hasspriteAt(float x, float y);
void					ft_readmap(char *argv);
void					ft_draw_sprites(void);
void					init_sprites(void);
void					ft_handle_bmp(void);
char					**fill_map(void);
void					free_array(char **tab);
void					ft_draw_texture(t_image ptr, int col, \
						float wallstripheight);
void					ft_empty_trash(float rayangle, int col);
void					get_text_data(void);
void					init_textures(void);
unsigned int			shadow(unsigned int color, int col);
unsigned int			rgb_to_int(unsigned int r, unsigned int g, \
						unsigned int b);
void					my_mlx_pixel_put(int x, int y, int color);
void					split_tab(char *line);
void					ressolution(int *x, int *y, char **tab);
void					save_path(char **path, char **text, \
						char **tab, int *i);
char					**ft_realloc(char **tab, char *element);
char					**ft_split(const char *str, char c);
void					free_tab(char **tab);
int						exit_game(int e);
void					init_identifiers(void);
void					check_color(char *line, int i);
void					check_map(void);
void					position_map(int i, int j);
void					check_identifier(char *line);
int						key_release_hook(int keycode, void *ptr);
int						key_press_hook(int keycode, void *ptr);
int						hasWallAt(float x, float y);
int						hasspriteAt(float x, float y);
void					move_player(void);
unsigned int			rgb_to_int(unsigned int r, unsigned int g, \
						unsigned int b);
void					cast(void);
int						ft_update(void);
void					get_player_pos(void);
void					init_struct(void);
float					normalizeAngle(float angle);
void					cast_ray(int col, float angle);
float					distanceBetweenPoints(float x1, float y1, \
						float x2, float y2);
void					dda(float X0, float Y0, float X1, float Y1);
void					ray_direction(float angle);
void					init(char **argv);
void					check_error(void);
void					help_nor2(int col);
void					help_norm(void);
void					castwhile2(float touchX, float touchY);
void					castwhile(float touchX, float touchY);
void					help_cast(void);
char					*save_texture(char *line, int i);
int						save_color(char *line, int i);
int						ft_isspace(int c);
int						ternary(int condition, int ret1, int ret2);
void					ft_sort_sprites(void);
void					ft_draw_sprites(void);
void					ft_sprite(int i);
void					dirangle(int i, int j);
void					norm_texture(char *line, int i);
void					norm_file(char *line, int i);
void					loop(char *line, int i);
void					set_resolution(char **tab, int i, int len);
int						iterate_map(int i);
int						condition(char **map, int i, int j);
void					normtext(char *line, int i);
int						ft_issymbol(int c);
void					norm_save_color(char *line, int i, int j);
#endif
