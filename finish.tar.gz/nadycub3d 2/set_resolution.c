/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   set_resolution.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/30 05:35:54 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 22:48:52 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	set_resolution(char **tab, int i, int len)
{
	if (g_text.r >= 1)
		exit_game(13);
	g_text.r += 1;
	if (ft_strlen(tab[0]) != 1)
		exit_game(13);
	if (ft_tablen(tab) != 3)
		exit_game(23);
	len = ft_strlen(tab[1]);
	while (++i < len)
	{
		if (!ft_isdigit(tab[1][i]))
			exit_game(23);
	}
}

int	iterate_map(int i)
{
	int	j;

	if (!g_tab)
		exit_game(6);
	while (++i < g_game_data.big_colon)
	{
		g_tab[i] = malloc(sizeof(char) * g_game_data.big_line + 1);
		if (!(g_tab[i]))
			exit_game(6);
		j = -1;
		while (++j < g_game_data.big_line)
		{
			if (j < ft_strlen(g_map[i]))
				g_tab[i][j] = g_map[i][j];
			else
				g_tab[i][j] = ' ';
		}
		g_tab[i][j] = '\0';
		free(g_map[i]);
	}
	return (i);
}

int	condition(char **map, int i, int j)
{
	if (map[i][j] == '0' || map[i][j] == 'N' || map[i][j] == 'S' || \
map[i][j] == 'E' || map[i][j] == 'W')
		if (map[i - 1][j] == ' ' || map[i + 1][j] == ' ' || \
map[i][j - 1] == ' ' || map[i][j + 1] == ' ')
			return (1);
	return (0);
}

void	normtext(char *line, int i)
{
	if (line[i] == 'W' && line[i + 1] == 'E' )
	{
		if (g_text.we >= 1)
			exit_game(17);
		g_text.we += 1;
		g_game_data.we_path = save_texture(line, i);
	}
	if (line[i] == 'S' && line[i + 1] == ' ' )
	{
		if (g_text.s >= 1)
			exit_game(18);
		g_text.s += 1;
		g_game_data.s_path = save_texture(line, i);
	}
}

void	init_identifiers(void)
{
	g_text.no = 0;
	g_text.ea = 0;
	g_text.so = 0;
	g_text.we = 0;
	g_text.s = 0;
	g_text.f = 0;
	g_text.c = 0;
}
