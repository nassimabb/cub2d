/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_key.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/18 14:22:36 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/31 22:47:58 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	my_mlx_pixel_put(int x, int y, int color)
{
	if (x < g_game_data.resolution_x && y < g_game_data.resolution_y && \
x >= 0 && y >= 0)
		g_dst[y * (int)g_game_data.resolution_x + x] = color;
}

int	key_press_hook(int keycode, void *ptr)
{
	ptr = NULL;
	if (keycode == EXIT_KEY)
		exit(1);
	if (keycode == KEY_UP)
		g_nassim.walkdirection = 1;
	if (keycode == KEY_DOWN)
		g_nassim.walkdirection = -1;
	if (keycode == KEY_RIGHT)
		g_nassim.turndirection = 1;
	if (keycode == KEY_LEFT)
		g_nassim.turndirection = -1;
	if (keycode == W)
		g_nassim.walkdirection = 1;
	if (keycode == S)
		g_nassim.walkdirection = -1;
	if (keycode == D)
		g_nassim.turndirection = 1;
	if (keycode == A)
		g_nassim.turndirection = -1;
	return (1);
}

int	key_release_hook(int keycode, void *ptr)
{
	ptr = NULL;
	if (keycode == 259 || keycode == 260)
		g_nassim.turndirection = 0;
	if (keycode == 259 || keycode == 260)
		g_nassim.walkdirection = 0;
	if (keycode == KEY_UP)
		g_nassim.walkdirection = 0;
	if (keycode == KEY_DOWN)
		g_nassim.walkdirection = 0;
	if (keycode == KEY_RIGHT)
		g_nassim.turndirection = 0;
	if (keycode == KEY_LEFT)
		g_nassim.turndirection = 0;
	if (keycode == W)
		g_nassim.walkdirection = 0;
	if (keycode == S)
		g_nassim.walkdirection = 0;
	if (keycode == D)
		g_nassim.turndirection = 0;
	if (keycode == A)
		g_nassim.turndirection = 0;
	return (1);
}

unsigned int	rgb_to_int(unsigned int r, unsigned int g, unsigned int b)
{
	int	c;

	c = r;
	c = (c << 8) | g;
	c = (c << 8) | b;
	return (c);
}

void	norm_file(char *line, int i)
{
	if (false)
		exit_game(1);
	else if (line[i] == 'F' && line[i + 1] == ' ')
	{
		if (g_text.f >= 1)
			exit_game(19);
		g_text.f++;
		g_color.floor = save_color(line, i);
	}
	else if (line[i] == 'C' && line[i + 1] == ' ')
	{
		if (g_text.c >= 1)
			exit_game(20);
		g_text.c++;
		g_color.ceiling = save_color(line, i);
	}
	else if (ft_isdigit(line[i]) || line[i] == ' ')
	{
		while (line[i] == ' ')
			i++;
		loop(line, i);
		g_map = ft_realloc(g_map, line);
	}
}
