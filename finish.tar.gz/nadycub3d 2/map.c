/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   map.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/26 00:47:43 by mazoukni          #+#    #+#             */
/*   Updated: 2021/03/31 18:11:37 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

static void	columns_edges_map(void)
{
	int	i;
	int	j;

	i = 0;
	while (i < g_game_data.big_colon)
	{
		if (g_map[i][0] != '1' && g_map[i][0] != ' ')
			exit_game(32);
		i++;
	}
	i = 0;
	j = 0;
	while (i < g_game_data.big_colon)
	{
		while (g_map[i][j])
			j++;
		j--;
		if (g_map[i][j] != '1' && g_map[i][j] != ' ')
			exit_game(33);
		i++;
		j = 0;
	}
}

static void	edges_map(void)
{
	int	i;
	int	j;

	i = 0;
	while (++i < g_game_data.big_colon - 1)
	{
		j = 0;
		while (g_map[i][++j])
		{
			if (condition(g_map, i, j))
				exit_game(30);
		}
	}
}

static void	rows_edges_map(void)
{
	int	i;

	i = 0;
	while (g_map[0][i])
	{
		if (g_map[0][i] != '1' && g_map[0][i] != ' ')
			exit_game(30);
		i++;
	}
	i = 0;
	while (i < g_game_data.big_line)
	{
		if (g_map[g_game_data.big_colon - 1][i] != '1' && \
g_map[g_game_data.big_colon - 1][i] != ' ' && \
g_map[g_game_data.big_colon - 1][i] != '\0')
			exit_game(31);
		i++;
	}
}

void	position_map(int i, int j)
{
	if (ft_isalpha(g_map[i][j]) && g_map[i][j] != 'N' && \
g_map[i][j] != 'S' && g_map[i][j] != 'E' && \
g_map[i][j] != 'W')
		exit_game(11);
	if ((g_map[i][j] == 'N' || g_map[i][j] == 'S' || \
g_map[i][j] == 'E' || g_map[i][j] == 'W') && \
g_text.id == 0)
	{
		g_nassim.x = (i + 0.5) * TILE_SIZE;
		g_nassim.y = (j + 0.5) * TILE_SIZE;
		g_text.id = 1;
	}
	else if ((g_map[i][j] == 'N' || g_map[i][j] == 'S' || \
g_map[i][j] == 'E' || g_map[i][j] == 'W') && \
g_text.id == 1)
		exit_game(21);
}

void	check_map(void)
{
	if (g_text.id == 0)
		exit_game(22);
	edges_map();
	rows_edges_map();
	columns_edges_map();
}
