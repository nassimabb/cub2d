/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_helpmain.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:43:42 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/28 16:29:05 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void init (void)
{

	game_data.big_colon = 0;
	game_data.big_line = 0;  
	init_identifiers();
	ft_readmap();
	mlx = mlx_init();
	mlx_win = mlx_new_window(mlx, game_data.resolution_x, game_data.resolution_y, "CUb3d");
	img.img = NULL;
	map = fill_map();
	get_player_pos();
	check_map();
	init_struct();
	init_textures();
	init_sprites();
	mlx_hook(mlx_win, 2, 0, key_press_hook, "lll");
	mlx_hook(mlx_win, 3, 0, key_release_hook, "lll");

	mlx_loop_hook(mlx, &ft_update, "");

	mlx_loop(mlx);
}
