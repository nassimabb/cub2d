/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/17 15:46:56 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/29 04:18:56 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	check_identifier(char *line)
{
	int i;

	i = 0;
	if (line[i] == 'R' && text.r > 1)
		exit_game(13);
	if (line[i] == 'N' && line[i + 1] == 'O' && text.no > 1)
		exit_game(14);
	if (line[i] == 'S' && line[i + 1] == 'O' && text.so > 1)
		exit_game(15);
	if (line[i] == 'E' && line[i + 1] == 'A' && text.ea > 1)
		exit_game(16);
	if (line[i] == 'W' && line[i + 1] == 'E' && text.we > 1)
		exit_game(17);
	if (line[i] == 'S' && line[i + 1] == ' ' && text.s > 1)
		exit_game(18);
	if (line[i] == 'F' && line[i + 1] == ' ' && text.f > 1)
		exit_game(19);
	if (line[i] == 'C' && line[i + 1] == ' ' && text.c > 1)
		exit_game(20);
	//check_error();
}

void check_error(void)
{
	int i;
	int j;

	i = 0;

	while (i < game_data.big_colon)
	{
		j = 0;
		while (j < game_data.big_line)
		{
			printf("%c",map[i][j]);
			//if (map[i][j] != '1' && map[i][j] != '0' && map[i][j] != '2' && map[i][j] != 'N')
				//exit_game(cub, 11);
			j++;
		}
		i++;
	}

}
// void	check_file(t_cub *cub)
// {
// 	if (cub->id.r == 0 && cub->id.no == 0 && cub->id.so == 0 && \
// 			cub->id.ea == 0 && cub->id.we == 0 && cub->id.s == 0 && \
// 			cub->id.f == 0 && cub->id.c == 0 && cub->id.m == 0)
// 		exit_game(cub, 8);
// 	if (cub->id.m == 0)
// 		exit_game(cub, 9);
// 	if (cub->id.m - cub->map.rows > 1)
// 		exit_game(cub, 10);
// }

void	check_color(char *line, int i)
{
	int tmp;

	if (i == 1)
	{
		while (line[i])
		{
			if (ft_isalpha(line[i]))
				exit_game(26);
			i++;
		}
	}
	else
	{
		tmp = ft_atoi(&line[i]);
		if (tmp < 0 || tmp > 255)
			exit_game(27);
	}
}
