/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   readmaps.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/31 18:49:14 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/29 04:23:10 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"
void free_array(char **tab)
{
	int i;

	i = -1;
	while (tab[++i])
		free(tab[i]);
	free(tab);
}

int	ft_isspace(int c)
{
	if (c == ' ' || c == '\t' || c == '\v' || \
			c == '\f' || c == '\r' || c == '\n')
		return (1);
	return (0);
}

char **fill_map()
{
	char **tab;
	int i;
	int j;

	if(!(tab = malloc(sizeof(char*) * (game_data.big_colon + 1))))
		exit_game(6);
	i = 0;
	while (i < game_data.big_colon)
	{
		if(!(tab[i] = malloc(sizeof(char) * game_data.big_line + 1)))
			exit_game(6);
		j = 0;
		while (j < game_data.big_line)
		{
			if (j < ft_strlen(map[i]))
				tab[i][j] = map[i][j];
			else
				tab[i][j] = '1';
			j++;
		}
		tab[i][j] = '\0';
		free(map[i]);

		i++;
	}
	tab[i] = NULL;
	free(map);
	return tab;
}

char    **ft_realloc(char **tab, char *element)
{
	int     i;
	char    **ret;
	int     len;

	i = -1;
	len = 1;

	if (text.r != 1 || text.no != 1 || text.so != 1 || text.ea != 1 || text.we != 1 || text.s != 1 || text.f != 1 || text.c != 1)
		exit_game(12);
	if (tab)
		len = ft_tablen(tab) + 1;
	if(!(ret = (char **)malloc(sizeof(char *) * (len + 1))))
		exit_game(6);
	while (++i < len - 1)
		ret[i] = ft_strdup(tab[i]);
	free_tab(tab);
	ret[i] = ft_strdup(element);
	ret[i + 1] = NULL;
	game_data.big_colon += 1;
	if (game_data.big_line < ft_strlen(element))
		game_data.big_line = ft_strlen(element);

	return (ret);
}

void       ft_readmap(void)
{
	char *line;
	int fd;


	map = NULL;
	line = NULL;
	fd = open("map.cub",O_RDONLY);
	while (get_next_line(fd,&line) == 1)
	{
		split_tab(line);
		free(line);
	}
	free(line);
	close(fd);

}

void init_identifiers(void)
{
	text.no = 0;
	text.ea = 0;
	text.so = 0;
	text.we = 0;
	text.s = 0;
	text.f = 0;
	text.c = 0;
}

char		*save_texture(char *line, int i)
{
	char	*texture;

	while (ft_isalpha(line[i]))
		i++;
	while (ft_isspace(line[i]))
		i++;
	texture = ft_strdup(&line[i]);
	return (texture);
}
