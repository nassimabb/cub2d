/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_readmap2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mazoukni <mazoukni@student.1337.ma>        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/15 18:32:56 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/29 04:19:51 by mazoukni         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

void	free_tab(char **tab)
{
	int i;

	i = -1;
	if (tab)
	{
		while (tab[++i])
			free(tab[i]);
		free(tab);
	}
}

void handle_texture(char *line, int i)
{
	if (line[i] == 'N' && line[i + 1] == 'O' && text.no == 0)
	{
		text.no = 1;
		game_data.no_path = save_texture(line, i);
	}
	if (line[i] == 'S' && line[i + 1] == 'O' && text.so == 0)
	{
		text.so = 1;
		game_data.so_path = save_texture(line, i);
	}
	if (line[i] == 'E' && line[i + 1] == 'A' && text.ea == 0)
	{

		text.ea = 1;
		game_data.ea_path = save_texture(line, i);
	}
	if (line[i] == 'W' && line[i + 1] == 'E' && text.we == 0)
	{
		text.we = 1;
		game_data.we_path = save_texture(line, i);
	}
	if (line[i] == 'S' && line[i + 1] == ' ' && text.s == 0)
	{
		text.s = 1;
		game_data.s_path = save_texture(line, i);
	}
}


void    split_tab(char *line)
{
	int i;
	i = 0;
	char **tab = ft_split(line ,' ');
	if (ft_tablen(tab))
	{
		handle_texture(line, i);
		if (!ft_strncmp(tab[0],"R",1))
			ressolution(&game_data.resolution_x, &game_data.resolution_y, tab);
		if (line[i] == 'F' && line[i + 1] == ' ' && text.f == 0)
		{
			text.f = 1;
			color.floor = save_color(line, i);
		}
		if (line[i] == 'C' && line[i + 1] == ' ' && text.c == 0)
		{
			text.c = 1;
			color.ceiling = save_color(line, i);
		}
		else if (ft_isdigit(*line) || *line == ' ')
		{
			while(*line == ' ' || *line =='\t')
				line++;
			while (*(line + i) != '\0')
			{
				//printf("%c", line[i]);
				if (*(line + i) != '0' && *(line +i) != '1' && *(line + i) != '2' && *(line + i) != 'N' && *(line + i) != 'W' && *(line + i) != 'S' && *(line + i) != 'E')
					exit_game(11);
				i++;
			}
			map = ft_realloc(map, line);
			// check_map(cub);
		}
		check_identifier(tab[0]);
	}
	free_tab(tab);

}

void    ressolution(int* x , int* y, char **tab)
{
	text.r += 1;
	if (ft_strlen(tab[0]) != 1)
		exit_game(13);
	if (ft_tablen(tab) != 3)
		exit_game(23);
	int i;
	int len = ft_strlen(tab[1]);
	i = -1;
	while (++i < len)
		if (!ft_isdigit(tab[1][i]))
			exit_game(23);
	i = -1;
	len = ft_strlen(tab[2]);
	while (++i < len)
		if (!ft_isdigit(tab[2][i]))
			exit_game(23);
	*x = ft_atoi(tab[1]);
	*y = ft_atoi(tab[2]);
	if (*x > 2561 )
		*x = 2560;
	if (*y > 1440)
		*y = 1440;
	//free_tab(tab);
}

void save_path(char **path, char **text, char **tab, int *i)
{
	*i += 1;
	char *ext;
	if (ft_strlen(tab[0]) >= 3)
		exit_game(24);
	*path = ft_strdup(tab[0]);
	*text = ft_strdup(tab[1]);
	if (*text == NULL)
		exit_game(6);
	//tab[2] = ft_strjoin(" ",tab[2]);
	//tab[1] = ft_strjoin(tab[1],tab[2]);
	//printf("%s",tab[1]);
	ext = ft_strrchr(tab[1], '.');
	if (ft_strncmp(ext + 1,"xpm",3) != 0 || ft_strlen(ext + 1) > 3)
		exit_game(10);
	//free_tab(tab);
}

int			save_color(char *line, int i)
{
	int color;

	i++;
	check_color(line, i);
	while (ft_isspace(line[i]))
		i++;
	check_color(line, i);
	color = ft_atoi(&line[i]) * pow(2, 16);
	while (ft_isdigit(line[i]))
		i++;
	if (line[i] != ',')
		exit_game(28);
	while (line[i] == ',' || line[i] == ' ')
		i++;
	check_color(line, i);
	color += ft_atoi(&line[i]) * pow(2, 8);
	while (ft_isdigit(line[i]))
		i++;
	if (line[i] != ',')
		exit_game(28);
	while (line[i] == ',' || line[i] == ' ')
		i++;
	check_color(line, i);
	color += ft_atoi(&line[i]);
	return (color);
}
