/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_cast.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 12:01:57 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/27 19:38:05 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"


void            cast(void)
{
	int i;
	float   rayangle;
	float   angle;

	i = 0;
	rayangle = (FOV_ANGLE / (game_data.resolution_x ));
	angle = (nassim.dirangle) - (FOV_ANGLE/2);
	while (i < game_data.resolution_x)
	{
		angle = normalizeAngle(angle);
		cast_ray(i, angle);
		angle += rayangle;
		i++;
	}
}

int            ft_update(void)
{
	if (img.img != NULL)
		mlx_destroy_image(mlx, img.img);

	img.img = mlx_new_image(mlx, game_data.resolution_x, game_data.resolution_y);

	dst = (int *)mlx_get_data_addr(img.img, &img.bits_per_pixel, &img.line_length,
			&img.endian);
	//draw_2d();
	move_player();

	cast();
	ft_draw_sprites();
	if (cub->save == 1)
	{
		ft_handle_bmp();
		exit(0);
	}
	mlx_put_image_to_window(mlx, mlx_win, img.img, 0, 0);
	return (0);
}

void            get_player_pos()
{
	int i; 
	int j;

	i = 0;
	text.id = 0;
	while (map[i] != NULL)
	{
		j = 0;
		while (map[i][j] != '\0')
		{
			if (map[i][j] == 'N' || map[i][j] == 'S' || map[i][j] == 'W' || map[i][j] == 'E')
			{
				if (map[i][j] == 'E')
					nassim.dirangle =   M_PI / 2;
				if (map[i][j] == 'W')
					nassim.dirangle  = 3 * M_PI / 2;
				if (map[i][j] == 'N')
					nassim.dirangle = M_PI;
				if (map[i][j] == 'S')
					nassim.dirangle  = 0;
				position_map(i, j);
			}
			j++;
		}
		i++;
	}
	nassim.dirangle = normalizeAngle(nassim.dirangle);
}

void    init_struct(void)
{
	nassim.rotationangle = M_PI;
	nassim.turndirection = 0;
	nassim.rotationspeed = 5 * M_PI / 180;
	nassim.walkdirection = 0;
	nassim.movespeed = 5.0;

}
