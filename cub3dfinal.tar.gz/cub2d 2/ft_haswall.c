/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_haswall.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 11:50:15 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/27 11:56:48 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

int     hasWallAt(float x, float y)
{


	int x0 = floor(x / TILE_SIZE);
	int y0 = floor(y / TILE_SIZE);

	//printf("||%d ' %d || %d ' %d\n", x0, y0,game_data.big_colon,  game_data.big_line  );
	//if (y0 >= game_data.big_line - 3)
	//return (0);
	if (x0 < 0 || x0  >= game_data.big_colon  || y0 < 0 || y0 >= game_data.big_line)
		return (0);
	else if (map[x0][y0] == '1' ) //|| map[x0][y0] == ' ')
		return (1);
	return (0);
}

int     hasspriteAt(float x, float y)
{


	int x0 = floor(x / TILE_SIZE);
	int y0 = floor(y / TILE_SIZE);

	//printf("||%d ' %d || %d ' %d\n", x0, y0,game_data.big_colon,  game_data.big_line  );
	//if (y0 >= game_data.big_line - 3)
	//return (0);
	if (x0 < 0 || x0  >= game_data.big_colon  || y0 < 0 || y0 >= game_data.big_line)
		return (0);
	else if (map[x0][y0] == '2' ) //|| map[x0][y0] == ' ')
		return (1);
	return (0);
}

void move_player()
{
	nassim.dirangle += nassim.turndirection * nassim.rotationspeed;

	nassim.movestep = nassim.walkdirection * nassim.movespeed;
	float x,y ;
	x = nassim.x + cos(nassim.dirangle) * nassim.movestep * 4;
	y = nassim.y + sin(nassim.dirangle) * nassim.movestep * 4;
	nassim.newplayerx = nassim.x + cos(nassim.dirangle) * nassim.movestep;
	nassim.newplayery = nassim.y + sin(nassim.dirangle) * nassim.movestep;

	if (!hasWallAt(x, y) && !hasspriteAt(x, y))
	{
		nassim.x = nassim.newplayerx;
		nassim.y = nassim.newplayery;
	}
}
