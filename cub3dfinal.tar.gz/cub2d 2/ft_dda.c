/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dda.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nabboudi <nabboudi@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/03/27 14:29:46 by nabboudi          #+#    #+#             */
/*   Updated: 2021/03/27 19:25:27 by nabboudi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "cub3d.h"

float normalizeAngle(float angle)
{
	float angler;

	angler = fmod(angle ,(2 * M_PI));
	if (angle < 0)
		angler = (2 * M_PI) + angle;
	return angler;
}

float distanceBetweenPoints(float x1,float y1, float x2, float  y2)
{
	return sqrtf((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
}

void dda(float  X0, float  Y0, float  X1, float  Y1) 
{ 
	// calculate dx & dy 
	int dx = X1 - X0; 
	int dy = Y1 - Y0; 
	// calculate steps required for generating pixels 
	int steps = abs(dx) > abs(dy) ? abs(dx) : abs(dy); 

	// calculate increment in x & y for each steps 
	float Xinc = dx / (float) steps; 
	float Yinc = dy / (float) steps; 

	// Put pixel for each step 
	float X = X0; 
	float Y = Y0; 
	for (int i = 0; i <= steps; i++) 
	{
		my_mlx_pixel_put(Y, X, color.colorr);
		X += Xinc;
		Y += Yinc; 

	} 
} 

void    ray_direction(float angle)
{
	ray.rayAngle = normalizeAngle(angle);
	ray.wallHitX = 0;
	ray.wallHitY = 0;
	ray.distance = 0;
	ray.wasHitVertical = false;

	ray.isRayFacingDown = ray.rayAngle > 0 && ray.rayAngle < M_PI;
	ray.isRayFacingUp = !ray.isRayFacingDown;

	ray.isRayFacingRight = ray.rayAngle < (0.5 * M_PI) || ray.rayAngle > (1.5 * M_PI);
	ray.isRayFacingLeft = !ray.isRayFacingRight;
}
